# Quotation expiry evidence package

This package preserves the result of the iEWR 7.0.6 first experiment. It contains the generated tool, tests, input, output, and recorded checks. The English agent assignment was run in a fresh extracted distribution and a new Codex CLI session. See the case page for the experiment conditions.

Extract into a separate folder. From that folder, run:

```sh
python3 project/artifacts/first-experiment/check_quotes.py project/source/first-experiment/quotes.csv project/artifacts/first-experiment/output.csv --as-of 2026-11-05
python3 -m unittest discover -s project/artifacts/first-experiment -v
```

These commands run the produced solution. Python 3 and its standard library are sufficient for this tool. CHECKS.json records the separate verification; PROVENANCE.json lists the SHA-256 hashes of the included files. Five tests and six output rows belong to this particular task.

To repeat the agent experiment, open a fresh copy of iEWR 7.0.6 in a new Codex session and submit [the original assignment](ASSIGNMENT_EN.txt). The assignment includes the input CSV data. [The Russian translation](ASSIGNMENT_RU.txt) was prepared separately and was not run in the recorded experiment.
