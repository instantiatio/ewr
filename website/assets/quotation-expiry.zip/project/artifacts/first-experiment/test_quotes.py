import csv
from datetime import date
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from check_quotes import parse_date, status, convert

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parents[1] / 'source/first-experiment/quotes.csv'


class QuotesTests(unittest.TestCase):
    def test_boundaries(self):
        for value, expected in [('2026-11-04', 'expired'), ('2026-11-05', 'valid'), ('2026-11-06', 'valid'), ('2026-02-30', 'invalid'), ('', 'invalid'), (None, 'invalid'), ('not-a-date', 'invalid'), ('2026-1-01', 'invalid'), (' 2026-11-05', 'invalid'), ('2026-11-05T00:00:00', 'invalid')]:
            with self.subTest(value=value):
                self.assertEqual(status(value, date(2026, 11, 5)), expected)
        self.assertEqual(status('2024-02-29', date(2024, 2, 29)), 'valid')
        with self.assertRaises(ValueError):
            parse_date('2025-02-29')

    def test_cli_and_preservation(self):
        before = SOURCE.read_bytes()
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / 'output.csv'
            run = subprocess.run([sys.executable, str(HERE / 'check_quotes.py'), str(SOURCE), str(output), '--as-of', '2026-11-05'], capture_output=True)
            self.assertEqual(run.returncode, 0, run.stderr)
            with output.open(newline='') as handle:
                rows = list(csv.reader(handle))
            with SOURCE.open(newline='') as handle:
                original = list(csv.reader(handle))
            self.assertEqual([row[:-1] for row in rows], original)
            self.assertEqual([row[-1] for row in rows[1:]], ['expired', 'valid', 'valid', 'invalid', 'invalid', 'invalid'])
        self.assertEqual(SOURCE.read_bytes(), before)

    def test_cli_requires_real_date(self):
        for arguments in [[], ['--as-of', '2026-02-30'], ['--as-of', '20261105']]:
            run = subprocess.run([sys.executable, str(HERE / 'check_quotes.py'), str(SOURCE), 'unused.csv'] + arguments, capture_output=True)
            self.assertEqual(run.returncode, 2)

    def test_same_file_rejected(self):
        with self.assertRaises(ValueError):
            convert(SOURCE, SOURCE, date(2026, 11, 5))

    def test_missing_field_and_later_row(self):
        with tempfile.TemporaryDirectory() as directory:
            source, output = Path(directory) / 'in.csv', Path(directory) / 'out.csv'
            source.write_text('id,valid_until,note\nA\nA,2026-11-05,"hello, world"\n')
            convert(source, output, date(2026, 11, 5))
            with output.open(newline='') as handle:
                self.assertEqual(list(csv.reader(handle))[1:], [['A', '', '', 'invalid'], ['A', '2026-11-05', 'hello, world', 'valid']])


if __name__ == '__main__':
    unittest.main()
