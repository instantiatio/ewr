"""Classify quotation expiry using an explicit calendar date."""
import argparse
import csv
from datetime import date
from pathlib import Path
import re


def parse_date(value):
    if not isinstance(value, str) or not re.fullmatch(r'[0-9]{4}-[0-9]{2}-[0-9]{2}', value):
        raise ValueError('expected a real YYYY-MM-DD date')
    return date.fromisoformat(value)


def status(value, as_of):
    try:
        until = parse_date(value)
    except ValueError:
        return 'invalid'
    return 'expired' if as_of > until else 'valid'


def convert(source, destination, as_of):
    if source.resolve() == destination.resolve() or (destination.exists() and source.samefile(destination)):
        raise ValueError('input and output must be different files')
    with source.open(newline='', encoding='utf-8') as handle:
        reader = csv.reader(handle, strict=True)
        header = next(reader, [])
        if header.count('id') != 1 or header.count('valid_until') != 1 or 'status' in header:
            raise ValueError('header needs unique id and valid_until columns and no status column')
        rows = list(reader)
    index = header.index('valid_until')
    # Preserve all original fields, even ragged records; pad missing fields.
    width = max([len(header)] + [len(row) for row in rows])
    header += ['extra_' + str(i) for i in range(len(header), width)]
    with destination.open('w', newline='', encoding='utf-8') as handle:
        writer = csv.writer(handle)
        writer.writerow(header + ['status'])
        for row in rows:
            row += [''] * (width - len(row))
            writer.writerow(row + [status(row[index], as_of)])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--as-of', required=True, type=parse_date)
    args = parser.parse_args()
    try:
        convert(args.input, args.output, args.as_of)
    except (ValueError, OSError, csv.Error) as error:
        parser.exit(2, f'error: {error}\n')


if __name__ == '__main__':
    main()
